<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function requireRole($role) {
  if (!isset($_SESSION['role']) || $_SESSION['role'] !== $role) {
    header('Location: /public/login.php');
    exit;
  }
}

function isLoggedIn() {
  return isset($_SESSION['user_id']);
}

function role() {
  return $_SESSION['role'] ?? null;
}
function requireLogin() {
  if (!isLoggedIn()) {
    header('Location: /public/login.php');
    exit;
  }
}