<?php
return [
  'mysql_host' => 'localhost',
  'mysql_dbname' => 'dents_city',
  'mysql_user' => 'root',
  'mysql_password' => '',
  'base_url' => 'http://localhost:8000', // adjust if using XAMPP
  'approved_roles' => ['client', 'dentist', 'admin'],
  'openai_api_key' => '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', // Replace with your actual OpenAI API key from https://platform.openai.com/api-keys
];
?>



